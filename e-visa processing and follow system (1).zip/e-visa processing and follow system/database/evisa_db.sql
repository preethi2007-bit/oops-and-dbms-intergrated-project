CREATE DATABASE IF NOT EXISTS evisa_db CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE evisa_db;

CREATE TABLE IF NOT EXISTS Users (
  user_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(30) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('APPLICANT','ADMIN') NOT NULL DEFAULT 'APPLICANT',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS Applicants (
  applicant_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL UNIQUE,
  date_of_birth DATE NULL,
  gender VARCHAR(30) NULL,
  nationality VARCHAR(80) NOT NULL,
  passport_number VARCHAR(40) NULL,
  address VARCHAR(500) NULL,
  CONSTRAINT fk_applicant_user FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS Visa_Types (
  visa_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  visa_name VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(500) NOT NULL,
  fee DECIMAL(10,2) NOT NULL,
  processing_period VARCHAR(60) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS Applications (
  application_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  reference_code VARCHAR(24) NOT NULL UNIQUE,
  applicant_id BIGINT NOT NULL,
  visa_id BIGINT NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  date_of_birth DATE NOT NULL,
  gender VARCHAR(30) NOT NULL,
  nationality VARCHAR(80) NOT NULL,
  passport_number VARCHAR(40) NOT NULL,
  passport_issue_date DATE NOT NULL,
  passport_expiry_date DATE NOT NULL,
  destination_country VARCHAR(100) NOT NULL,
  travel_purpose VARCHAR(500) NOT NULL,
  travel_start_date DATE NOT NULL,
  travel_end_date DATE NOT NULL,
  residential_address VARCHAR(500) NOT NULL,
  contact_phone VARCHAR(30) NOT NULL,
  submission_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  application_status ENUM('SUBMITTED','INITIAL_REVIEW','DOCUMENT_VERIFICATION','ADDITIONAL_DOCUMENTS','PROCESSING','APPROVED','REJECTED') NOT NULL DEFAULT 'SUBMITTED',
  CONSTRAINT fk_application_applicant FOREIGN KEY (applicant_id) REFERENCES Applicants(applicant_id),
  CONSTRAINT fk_application_visa FOREIGN KEY (visa_id) REFERENCES Visa_Types(visa_id),
  INDEX idx_application_status (application_status), INDEX idx_application_date (submission_date)
);
CREATE TABLE IF NOT EXISTS Documents (
  document_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  application_id BIGINT NOT NULL,
  document_type VARCHAR(80) NOT NULL,
  file_path VARCHAR(500) NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  verification_status ENUM('PENDING','VERIFIED','CORRECTION_REQUIRED') NOT NULL DEFAULT 'PENDING',
  uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_document_application FOREIGN KEY (application_id) REFERENCES Applications(application_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS Payments (
  payment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  application_id BIGINT NOT NULL,
  transaction_id VARCHAR(40) NOT NULL UNIQUE,
  amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('CARD','UPI','NET_BANKING') NOT NULL,
  payment_status ENUM('SUCCESS','FAILED') NOT NULL,
  payment_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_payment_application FOREIGN KEY (application_id) REFERENCES Applications(application_id)
);
CREATE TABLE IF NOT EXISTS Status_History (
  history_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  application_id BIGINT NOT NULL,
  old_status VARCHAR(40) NULL,
  new_status VARCHAR(40) NOT NULL,
  remarks VARCHAR(1000) NULL,
  updated_by BIGINT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_history_application FOREIGN KEY (application_id) REFERENCES Applications(application_id) ON DELETE CASCADE,
  CONSTRAINT fk_history_user FOREIGN KEY (updated_by) REFERENCES Users(user_id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS Notifications (
  notification_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  message VARCHAR(1000) NOT NULL,
  notification_type VARCHAR(60) NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
  INDEX idx_notification_user_read (user_id,is_read)
);
CREATE TABLE IF NOT EXISTS Feedback (
  feedback_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  complaint VARCHAR(2000) NOT NULL,
  admin_response VARCHAR(2000) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_feedback_user FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

INSERT IGNORE INTO Visa_Types (visa_name,description,fee,processing_period) VALUES
('Tourist Visa','For holidays, sightseeing and visiting family.',75.00,'5–7 business days'),
('Student Visa','For study at a recognized educational institution.',120.00,'10–15 business days'),
('Business Visa','For meetings, conferences and business visits.',100.00,'5–8 business days'),
('Medical Visa','For medical consultation or treatment abroad.',90.00,'3–6 business days'),
('Employment Visa','For approved employment in the destination country.',150.00,'15–20 business days');

-- Create an administrator with the normal registration flow, then change its role:
-- UPDATE Users SET role='ADMIN' WHERE email='your-admin-email@example.com';
