package com.evisa.util;
import jakarta.servlet.http.*;

public final class Web {
  private Web() {}
  public static String esc(Object value) { if(value==null)return ""; return value.toString().replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;"); }
  public static Long userId(HttpServletRequest r) { Object v=r.getSession(false)==null?null:r.getSession(false).getAttribute("userId"); return v instanceof Long?(Long)v:null; }
  public static boolean require(HttpServletRequest r,HttpServletResponse p,String role) throws java.io.IOException {
    HttpSession s=r.getSession(false); if(s==null||s.getAttribute("userId")==null){p.sendRedirect(r.getContextPath()+"/login");return false;}
    if(role!=null&&!role.equals(s.getAttribute("role"))){p.sendError(403);return false;} return true;
  }
}
