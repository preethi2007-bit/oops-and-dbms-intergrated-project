package com.evisa.util;
import java.sql.*;

public final class DB {
  private DB() {}
  public static Connection get() throws SQLException {
    String url=System.getenv().getOrDefault("EVISA_DB_URL","jdbc:mysql://localhost:3306/evisa_db?useSSL=false&serverTimezone=UTC");
    String user=System.getenv().getOrDefault("EVISA_DB_USER","root");
    String password=System.getenv().getOrDefault("EVISA_DB_PASSWORD","");
    return DriverManager.getConnection(url,user,password);
  }
}
