package com.evisa.controller;
import com.evisa.util.DB;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.*;
import java.io.IOException;
import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

@WebServlet(urlPatterns={"/login","/register","/logout"})
public class AuthServlet extends HttpServlet {
  protected void doGet(HttpServletRequest q,HttpServletResponse p)throws IOException,ServletException{
    String path=q.getServletPath(); if(path.equals("/logout")){if(q.getSession(false)!=null)q.getSession().invalidate();p.sendRedirect(q.getContextPath()+"/");return;} q.getRequestDispatcher(path.equals("/login")?"/login.jsp":"/register.jsp").forward(q,p);
  }
  protected void doPost(HttpServletRequest q,HttpServletResponse p)throws IOException,ServletException{
    q.setCharacterEncoding("UTF-8"); String path=q.getServletPath();
    try(Connection c=DB.get()){
      if(path.equals("/register")){
        String name=q.getParameter("full_name"),email=q.getParameter("email"),phone=q.getParameter("phone"),nation=q.getParameter("nationality"),pass=q.getParameter("password"),confirm=q.getParameter("confirm_password");
        if(name==null||email==null||phone==null||nation==null||pass==null||!pass.equals(confirm)||pass.length()<10||!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")){q.setAttribute("error","Check your details. Passwords must match and be at least 10 characters.");q.getRequestDispatcher("/register.jsp").forward(q,p);return;}
        c.setAutoCommit(false); try(PreparedStatement u=c.prepareStatement("INSERT INTO Users(full_name,email,phone,password_hash) VALUES(?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){u.setString(1,name.trim());u.setString(2,email.trim().toLowerCase());u.setString(3,phone.trim());u.setString(4,BCrypt.hashpw(pass,BCrypt.gensalt(12)));u.executeUpdate();try(ResultSet k=u.getGeneratedKeys()){k.next();try(PreparedStatement a=c.prepareStatement("INSERT INTO Applicants(user_id,nationality) VALUES(?,?)")){a.setLong(1,k.getLong(1));a.setString(2,nation.trim());a.executeUpdate();}}}c.commit();p.sendRedirect(q.getContextPath()+"/login?registered=1");
      } else {
        String email=q.getParameter("email"),pass=q.getParameter("password"); try(PreparedStatement s=c.prepareStatement("SELECT user_id,full_name,password_hash,role FROM Users WHERE email=?")){s.setString(1,email==null?"":email.trim().toLowerCase());try(ResultSet r=s.executeQuery()){if(!r.next()||pass==null||!BCrypt.checkpw(pass,r.getString("password_hash"))){q.setAttribute("error","Email or password is incorrect.");q.getRequestDispatcher("/login.jsp").forward(q,p);return;}HttpSession session=q.getSession(true);session.setAttribute("userId",r.getLong("user_id"));session.setAttribute("name",r.getString("full_name"));session.setAttribute("role",r.getString("role"));session.setMaxInactiveInterval(30*60);p.sendRedirect(q.getContextPath()+("ADMIN".equals(r.getString("role"))?"/admin":"/applicant"));}}
      }
    }catch(SQLIntegrityConstraintViolationException e){q.setAttribute("error","That email address is already registered.");q.getRequestDispatcher("/register.jsp").forward(q,p);}catch(SQLException e){throw new ServletException("Authentication database operation failed",e);}
  }
}
