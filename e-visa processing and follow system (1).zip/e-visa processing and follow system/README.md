# Wayfarer E‑Visa Portal

Java 21, Maven WAR application for Apache Tomcat 10.1 with MySQL 8. The portal includes a responsive public landing page, applicant registration and login, database-backed applicant dashboard, visa application submission, simulated payment, application tracking, and a separate role-protected admin dashboard with status updates and notification generation.

## Run locally

1. In MySQL Workbench, execute `database/evisa_db.sql`.
2. Set `EVISA_DB_USER` and `EVISA_DB_PASSWORD` in the Tomcat launch environment. Optionally set `EVISA_DB_URL` (default: `jdbc:mysql://localhost:3306/evisa_db?useSSL=false&serverTimezone=UTC`).
3. Build from this directory with `mvn clean package` using JDK 21.
4. Deploy `target/evisa-portal.war` to Tomcat 10.1 and open `/evisa-portal/`.
5. Register a normal account. To create an administrator, run `UPDATE Users SET role='ADMIN' WHERE email='you@example.com';` in Workbench, then log in again.

Payments are academic simulations. This starter version does not connect to a payment provider. Uploaded documents and feedback UI are planned next modules; the schema is already present. For a production deployment, configure TLS, CSRF defenses, rate limiting, database credentials through a secret manager, and a private document store.
